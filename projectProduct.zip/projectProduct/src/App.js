import React, { Component } from 'react';
import './App.css';
import ProductForm from './components/ProductForm';
import Control from './components/control';
import { BrowserRouter as Router, Route, NavLink } from 'react-router-dom';
import ProductList from './components/ProductList';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            products: [], //id: unique, name, status, image
            isDisplayForm: false,
            productEditting: null,
            filter: {
                name: '',
                status: -1
            },
            keyword: ''
        }
    }

    componentWillMount() {
        if (localStorage && localStorage.getItem('products')) {
            var products = JSON.parse(localStorage.getItem('products'));
            this.setState({
                products: products
            })
        }
    }

    s4() {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1)
    }
    generateID() {
        return this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' +
            this.s4() + this.s4() + this.s4();
    }

    onToggleForm = () => {
        if (this.state.isDisplayForm && this.state.productEditting !== null) {
            this.setState({
                isDisplayForm: true,
                productEditting: null
            })
        } else {
            this.setState({
                isDisplayForm: !this.state.isDisplayForm,
                productEditting: null
            })
        }
    }

    onCloseForm = () => {
        this.setState({
            isDisplayForm: false
        })
    }

    onShowForm = () => {
        this.setState({
            isDisplayForm: true
        })
    }

    onSubmit = (data) => {
        // if (data === null) {
        // }
        var { products } = this.state;
        if (data.id === '') {
            data.id = this.generateID();
            products.push(data);
            alert('Đã thêm');
        } else {
            //editting
            var index = this.findIndex(data.id);
            products[index] = data;
            alert('Đã sửa');
        }

        this.setState({
            products: products,
            productEditting: null
        });
        localStorage.setItem('products', JSON.stringify(products));        
    }

    updateStatus = (id) => {
        var { products } = this.state;
        var index = this.findIndex(id);
        if (index !== -1) {
            products[index].status = !products[index].status
            this.setState({
                products: products
            });
        }
        localStorage.setItem('products', JSON.stringify(products));        
    }

    findIndex = (id) => {
        var { products } = this.state;
        var result = -1;
        products.forEach((product, index) => {
            if (product.id === id) {
                result = index
            }
        });
        return result;
    }

    onDeleteItem = (id) => {
        var { products } = this.state;
        var index = this.findIndex(id);
        if (index !== -1) {
            products.splice(index, 1)
            this.setState({
                products: products
            });
        }
        localStorage.setItem('products', JSON.stringify(products));
        this.onCloseForm();
    }

    onUpdate = (id) => {
        var { products } = this.state;
        var index = this.findIndex(id);
        var productEditting = products[index];
        this.setState({
            productEditting: productEditting
        })
        this.onShowForm();       
    }

    onFilter = (filterName, filterStatus) => {
        filterStatus = parseInt(filterStatus)
        this.setState({
            filter: {
                name: filterName.toLowerCase(),
                status: filterStatus
            }
        })
    }

    onSearch = (keyword) => {
        this.setState({
            keyword: keyword
        })
    }

    render() {
        var { products, isDisplayForm, productEditting, filter, keyword } = this.state

        if (filter) {
            if (filter.name) {
                products = products.filter((product) => {
                    return product.name.toLowerCase().indexOf(filter.name) !== -1;
                });
            }

            products = products.filter((product) => {
                if (filter.status === -1) {
                    return product;
                }
                else {
                    return product.status === (filter.status === 1 ? true : false)
                }
            });
        }

        if (keyword) {
            products = products.filter((product) => {
                return product.name.toLowerCase().indexOf(keyword) !== -1;
            });
        }

        var elementForm = isDisplayForm === true ? <ProductForm
                                                    onSubmit={this.onSubmit}
                                                    onCloseForm={this.onCloseForm}
                                                    product={productEditting}
                                                   />
                                                : '';
        return (
            <div className="container">
                <Router>
                    {/* menu */}
                    <nav className="navbar navbar-inverse">
                        <ul className="nav navbar-nav">
                            <li>
                                <NavLink activeClassName='active' exact to="/" className="my-link">Trang chủ</NavLink>
                            </li>
                            <li>
                                <NavLink activeClassName='active' to="/producform" className="my-link">Thêm mới</NavLink>
                            </li>

                        </ul>
                    </nav>
                    {/* noi dung */}
                    <Route path="/producform" component={ProductForm} />

                </Router>
                <div className="text-center">
                    <h1>Quản lý sản phẩm</h1><hr />
                </div>

                <div className="row">
                    {/* productname */}
                    <div className={isDisplayForm === true ? "col-xs-4 col-sm-4 col-md-4 col-lg-4" : ""}>
                        {elementForm}
                    </div>

                    <div className={isDisplayForm === true ? "col-xs-8 col-sm-8 col-md-8 col-lg-8" : "col-xs-12 col-sm-12 col-md-12 col-lg-12"}>
                        <button type="button" className="btn btn-primary" onClick={this.onToggleForm}>
                            <span className="fa fa-plus"></span>&nbsp;
                            Thêm sản phẩm
                        </button>&nbsp;

                        {/* search-sort */}
                        <Control onSearch={this.onSearch} />
                        <div className="row mt-15">

                            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                {/* table */}
                                <ProductList
                                    products={products}
                                    onUpdateStatus={this.updateStatus}
                                    onDeleteItem={this.onDeleteItem}
                                    onUpdate={this.onUpdate}
                                    onFilter={this.onFilter}
                                />
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        );
    }
}
export default App;
