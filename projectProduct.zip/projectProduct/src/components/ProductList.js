import React, { Component } from 'react';
import ProductItem from './ProductItem';
class ProductList extends Component {
    constructor(props) {
        super(props);
        this.state = {
             filterName: '',
             filterStatus : null
        }
    }
    
    // updateStatus = (value)=>{
    //     this.props.onUpdateStatus(value);
    // }

    onChange = (event)=>{
        var target = event.target;
        var name = target.name;
        var value = target.value;
        this.props.onFilter(
            name === 'filterName' ? value : this.state.filterName,
            name === 'filterStatus' ? value : this.state.filterStatus
        )
        this.setState({
            [name] : value
        })
    }

    render() {
        var { products } = this.props 
        var { filterName, filterStatus } = this.state;
        var elementproducts = products.map((product, index)=>{
            return <ProductItem 
                        key={product.id}
                        index={index}
                        product={product}
                        onUpdateStatus = {this.props.onUpdateStatus}
                        onDeleteItem = {this.props.onDeleteItem}
                        onUpdate = {this.props.onUpdate}
                    />
        })
        return (
            <table className="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th className="text-center">STT</th>
                        <th className="text-center">Tên sản phẩm</th>
                        <th className="text-center">Giá bán</th>
                        <th className="text-center">Hình ảnh</th>
                        <th className="text-center">Trạng thái</th>
                        <th className="text-center">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td>
                            <input type="text" className="form-control" id="filterName" name='filterName' value={ filterName } onChange={this.onChange} />
                        </td>
                        <td></td>
                        <td></td>
                        <td>
                            <select className="form-control" id='filterStatus' name='filterStatus' value={ filterStatus } onChange={this.onChange} >                              
                                <option value={-1}>Tất cả</option>
                                <option value={0}>Hết hàng </option>
                                <option value={1}>Còn hàng</option>                
                            </select>
                        </td>
                        <td></td>
                    </tr>
                    {elementproducts}                 
                </tbody>
            </table>
        );
    }
}
export default ProductList;
