import React, { Component } from 'react';
import ProductList from './ProductList';
import ProductItem from './ProductItem';
import ProductForm from './ProductForm';
import Control from './control';

class ShowList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            products: [], //id: unique, name, status, image
            isDisplayForm: false,
            productEditting: null,
            filter: {
                name: '',
                status: -1
            },
            keyword: ''
        }
    }

    s4() {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1)
    }
    generateID() {
        return this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' +
            this.s4() + this.s4() + this.s4();
    }

    onToggleForm = () => {
        if (this.state.isDisplayForm && this.state.productEditting !== null) {
            this.setState({
                isDisplayForm: true,
                productEditting: null
            })
        } else {
            this.setState({
                isDisplayForm: !this.state.isDisplayForm,
                productEditting: null
            })
        }
    }

    onCloseForm = () => {
        this.setState({
            isDisplayForm: false
        })
    }

    onShowForm = () => {
        this.setState({
            isDisplayForm: true
        })
    }

    onSubmit = (data) => {
        if (data === null) {
        }
        var { products } = this.state;
        if (data.id === '') {
            data.id = this.generateID();
            products.push(data);
        } else {
            //editting
            var index = this.findIndex(data.id);
            products[index] = data
        }

        this.setState({
            products: products,
            productEditting: null
        });
        localStorage.setItem('products', JSON.stringify(products));
        alert('Đã thêm');
    }

    updateStatus = (id) => {
        var { products } = this.state;
        var index = this.findIndex(id);
        if (index !== -1) {
            products[index].status = !products[index].status
            this.setState({
                products: products
            });
        }
        localStorage.setItem('products', JSON.stringify(products));
    }

    findIndex = (id) => {
        var { products } = this.state;
        var result = -1;
        products.forEach((product, index) => {
            if (product.id === id) {
                result = index
            }
        });
        return result;
    }

    onDeleteItem = (id) => {
        var { products } = this.state;
        var index = this.findIndex(id);
        if (index !== -1) {
            products.splice(index, 1)
            this.setState({
                products: products
            });
        }
        localStorage.setItem('products', JSON.stringify(products));
        this.onCloseForm();
    }

    onUpdate = (id) => {
        var { products } = this.state;
        var index = this.findIndex(id);
        var productEditting = products[index];
        this.setState({
            productEditting: productEditting
        })
        this.onShowForm();
    }

    onFilter = (filterName, filterStatus) => {
        filterStatus = parseInt(filterStatus)
        this.setState({
            filter: {
                name: filterName.toLowerCase(),
                status: filterStatus
            }
        })
    }

    onSearch = (keyword) => {
        this.setState({
            keyword: keyword
        })
    }

    render() {
        var { products, isDisplayForm, productEditting, filter, keyword } = this.state
        return (
            <div>
                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    {/* table */}
                    <ProductList
                        products={products}
                        onUpdateStatus={this.updateStatus}
                        onDeleteItem={this.onDeleteItem}
                        onUpdate={this.onUpdate}
                        onFilter={this.onFilter}
                    />
                </div>            
            </div>
        );
    }
}

export default ShowList;