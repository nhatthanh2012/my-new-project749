import React, { Component } from 'react';

class ProductItem extends Component {

    onUpdateStatus = () => {
        this.props.onUpdateStatus(this.props.product.id);        
    }

    onDeleteItem = () => {       
        this.props.onDeleteItem(this.props.product.id);   
    }

    onUpdate = ()=>{
        this.props.onUpdate(this.props.product.id);  
    }
    
    render() {
        var {product, index } = this.props;        
        return (
            <tr>
                <td>{index + 1}</td>
                <td>{product.name}</td>
                <td className="text-center">{product.price} VND</td>
                <td className="text-center">
                    <img src={product.image} alt="product" ></img>
                </td>
                <td className="text-center">
                    <span onClick={ this.onUpdateStatus } className={product.status === true ? "label label-success" : "label label-danger"}>
                        {product.status === true ? "Còn hàng" : "Hết hàng"}
                    </span>
                </td>
                <td className="text-center">
                    <button type="button" className="btn btn-warning" onClick={this.onUpdate}>
                        <i class="fas fa-edit"></i>&nbsp;   
                          Sửa
                    </button>&nbsp;

                    <button type="button" className="btn btn-danger" onClick={e =>window.confirm('Bạn có chắc muốn xóa ?') && this.onDeleteItem(e)} >
                        <i class="fas fa-trash-alt"></i>&nbsp;   
                          Xóa
                    </button>
                </td>
            </tr>
        );
    }
}
export default ProductItem;
