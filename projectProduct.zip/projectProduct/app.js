const app = require('./config/server');

app.listen(3000, () => console.log('Connected on port 3000.'));