module.exports = {

    index: (req, res) => {
        res.send('Hello, World!');
    }

}